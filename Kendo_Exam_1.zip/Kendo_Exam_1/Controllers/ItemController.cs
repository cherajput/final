using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Kendo_Exam_1.Models;
using Microsoft.Extensions.Logging;
using Kendo_Exam_1.Repositories;

namespace Kendo_Exam_1.Controllers;

public class ItemController : Controller
{
    private readonly ILogger<ItemController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IItemRepository _itemRepository;
    private readonly IPurchaseRepository purchaseRepository;
     private readonly IWebHostEnvironment _environment;
     

    public ItemController(ILogger<ItemController> logger, IUserRepository userRepository, IItemRepository itemRepository, IWebHostEnvironment environment, IPurchaseRepository purchaseRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _itemRepository = itemRepository;
        _environment = environment;
        this.purchaseRepository = purchaseRepository;
    }
   
    [HttpGet]
    public IActionResult AddItem()
    {
        return View();
    }
    
    [HttpPost]
    public IActionResult AddItem(Item item)
    {
        if (item.Image != null && item.Image.Length > 0)
        {
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var uniqueFileName = Guid.NewGuid().ToString() + "_" + item.Image.FileName;
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                item.Image.CopyTo(stream);
            }

            item.c_image = uniqueFileName; // Save the file name to the database
        }

        _itemRepository.AddItem(item);
        return RedirectToAction("Index", "user"); // Redirect to home page or any other action
    }

   [HttpGet]
    public IActionResult Update(int id)
    {
        var item = _itemRepository.GetItemById(id);
        return View(item);

    }

    [HttpPost]
    public IActionResult Update(Item item)
    {
        var olditem = _itemRepository.GetItemById(item.c_id);
        if (item.Image != null && item.Image.Length > 0)
        {
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var uniqueFileName = Guid.NewGuid().ToString() + "_" + item.Image.FileName;
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                item.Image.CopyTo(stream);
            }

            item.c_image = uniqueFileName; // Save the file name to the database
        }
        else
        {
            item.c_image = olditem.c_image;
        }

        _itemRepository.UpdateItem(item);
        return Json(item); // Convert the item to JSON and return it
    }

    [HttpPost]
    public IActionResult Delete(int id)
    {
        _itemRepository.DeleteItem(id);
        var response = new { message = "Item deleted successfully" };
        return View(response);
    }

     public IActionResult Index()
    {
        if (HttpContext.Session.GetString("c_username") == null)
        {
            return RedirectToAction("login", "user");
        }

        var items = _itemRepository.GetItems();
        return View(items);
    }

    public IActionResult UserPurchasedItem()
    {
        if (HttpContext.Session.GetString("c_username") == null)
        {
            return RedirectToAction("login", "user");
        }
        var items = purchaseRepository.GetPurchases();
        return View(items);
    }

    [HttpGet]
    public IActionResult PurchasedItem()
    {
        var item = TempData["PurchaseItem"];

        return View(item);
    }

    [HttpPost]
    public IActionResult PurchasedItem([FromBody] purchase item)
    {
        purchaseRepository.AddPurchase(item);
        return Ok("success");
    }







}

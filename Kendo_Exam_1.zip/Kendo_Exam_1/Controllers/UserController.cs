using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Kendo_Exam_1.Models;
using Microsoft.Extensions.Logging;
using Kendo_Exam_1.Repositories;

namespace Kendo_Exam_1.Controllers;

public class UserController : Controller
{
    private readonly ILogger<UserController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IItemRepository _itemRepository;

    public UserController(ILogger<UserController> logger, IUserRepository userRepository, IItemRepository itemRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _itemRepository = itemRepository;
    }
   


    [HttpGet]
    public IActionResult GetItems()
    {
        var items = _itemRepository.GetItems();
        return Json(items);
    }
     [HttpGet]
    public IActionResult Index()
      {
            
            if (HttpContext.Session.GetString("c_username") == null)
            {
                return RedirectToAction("login", "user");
            }
            // var items = _itemRepository.GetItems();
            return View();
           

      }
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Login(UserMaster login)
    {
        if(_userRepository.Login(login))
        {
            if(HttpContext.Session.GetString("c_role") == "admin")
            {
                return RedirectToAction("Index", "User");
            }
            else if(HttpContext.Session.GetString("c_role") == "user")
            {
                return RedirectToAction("Index", "Item");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        else
        {
            return RedirectToAction("Index", "Home");
        }
    }
    // [HttpGet]
    // public IActionResult Index()
    //   {
            
    //         if (HttpContext.Session.GetString("c_username") == null)
    //         {
    //             return RedirectToAction("login", "user");
    //         }
    //         var items = _itemRepository.GetItems();
    //         return View(items);
           

    //     }

}

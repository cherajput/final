using Kendo_Exam_1.Repositories;
using Kendo_Exam_1.Models;

namespace Kendo_Exam_1.Repositories
{
    public interface IItemRepository
    {
       public void  AddItem (Item add);
       public List<Item> GetItems();
       public void UpdateItem(Item update);
       public Item GetItemById(int id); 
       public void DeleteItem(int id);
    }
}

using Kendo_Exam_1.Models;
namespace Kendo_Exam_1.Repositories

{
    public interface IPurchaseRepository
    {
        public void AddPurchase(purchase purchase);
        public List<purchase> GetPurchases();
        public purchase GetPurchaseById(int id);
        // public void UpdatePurchase(purchase purchase);
        // public void DeletePurchase(int id);
    }
}
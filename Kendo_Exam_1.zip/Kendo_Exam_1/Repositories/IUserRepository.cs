using Kendo_Exam_1.Repositories;
using Kendo_Exam_1.Models;

namespace Kendo_Exam_1.Repositories
{
    public interface IUserRepository
    {
      public bool Login (UserMaster login);
    }
}

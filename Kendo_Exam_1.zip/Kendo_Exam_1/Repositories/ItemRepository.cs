using Npgsql;
using Kendo_Exam_1.Models;

namespace Kendo_Exam_1.Repositories
{
    public class ItemRepository : IItemRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor access;
        public ItemRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            _conn = config.GetConnectionString("Kali");
            conn = new NpgsqlConnection(_conn);
            access = accessor;
        }

        public void  AddItem (Item add)
        {
            try
            {
                conn.Open();
                var query = "INSERT INTO t_items (c_name, c_category, c_image, c_cost_per_unit, c_initial_stock, c_available_stock) VALUES (@c_name, @c_category, @c_image, @c_cost_per_unit, @c_initial_stock, @c_available_stock)";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_name", add.c_name);
                cmd.Parameters.AddWithValue("@c_category", add.c_category);
                cmd.Parameters.AddWithValue("@c_image", add.c_image);
                cmd.Parameters.AddWithValue("@c_cost_per_unit", add.c_cost_per_unit);
                cmd.Parameters.AddWithValue("@c_initial_stock", add.c_initial_stock);
                cmd.Parameters.AddWithValue("@c_available_stock", add.c_available_stock);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
               Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }

        public List<Item> GetItems()
        {
            List<Item> items = new List<Item>();
            try
            {
                conn.Open();
                var query = "SELECT * FROM t_items";
                var cmd = new NpgsqlCommand(query, conn);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Item item = new Item();
                    item.c_id = Convert.ToInt32(reader["c_id"]);
                    item.c_name = reader["c_name"].ToString();
                    item.c_category = reader["c_category"].ToString();
                    item.c_image = reader["c_image"].ToString();
                    item.c_cost_per_unit = Convert.ToInt32(reader["c_cost_per_unit"]);
                    item.c_initial_stock = Convert.ToInt32(reader["c_initial_stock"]);
                    item.c_available_stock = Convert.ToInt32(reader["c_available_stock"]);
                    items.Add(item);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return items;
        }

        public Item GetItemById(int id)
        {
            Item item = new Item();
            try
            {
                conn.Open();
                var query = "SELECT * FROM t_items WHERE c_id = @c_id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_id", id);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    item.c_id = Convert.ToInt32(reader["c_id"]);
                    item.c_name = reader["c_name"].ToString();
                    item.c_category = reader["c_category"].ToString();
                    item.c_image = reader["c_image"].ToString();
                    item.c_cost_per_unit = Convert.ToInt32(reader["c_cost_per_unit"]);
                    item.c_initial_stock = Convert.ToInt32(reader["c_initial_stock"]);
                    item.c_available_stock = Convert.ToInt32(reader["c_available_stock"]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return item;
        }

        public void UpdateItem(Item update)
        {
            try
            {
                conn.Open();
                var query = "UPDATE t_items SET c_name = @c_name, c_category = @c_category, c_image = @c_image, c_cost_per_unit = @c_cost_per_unit, c_initial_stock = @c_initial_stock, c_available_stock = @c_available_stock WHERE c_id = @c_id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_id", update.c_id);
                cmd.Parameters.AddWithValue("@c_name", update.c_name);
                cmd.Parameters.AddWithValue("@c_category", update.c_category);
                cmd.Parameters.AddWithValue("@c_image", update.c_image);
                cmd.Parameters.AddWithValue("@c_cost_per_unit", update.c_cost_per_unit);
                cmd.Parameters.AddWithValue("@c_initial_stock", update.c_initial_stock);
                cmd.Parameters.AddWithValue("@c_available_stock", update.c_available_stock);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteItem(int id)
        {
            try
            {
                conn.Open();
                var query = "DELETE FROM t_items WHERE c_id = @c_id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_id", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        

    }
}
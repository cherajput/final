using Npgsql;
using Kendo_Exam_1.Models;

namespace Kendo_Exam_1.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor access;
        public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            _conn = config.GetConnectionString("Kali");
            conn = new NpgsqlConnection(_conn);
            access = accessor;
        }

        public bool Login (UserMaster login)
        {
            try
            {
                conn.Open();
                var query = "SELECT * FROM t_usermaster WHERE c_email = @c_email AND c_password = @c_password";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_email", login.c_email);
                cmd.Parameters.AddWithValue("@c_password", login.c_password);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string c_roles = reader["c_role"].ToString();
                    string c_password = reader["c_password"].ToString();

                    access.HttpContext.Session.SetString("c_role", c_roles);
                    access.HttpContext.Session.SetString("c_password", c_password);
                    access.HttpContext.Session.SetString("c_email", login.c_email);
                    access.HttpContext.Session.SetString("c_username", reader["c_username"].ToString());
                    access.HttpContext.Session.SetInt32("userid", reader.GetInt32(0));

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
             Console.WriteLine(e.Message);   
            }
            finally
            {
                conn.Close();
            }
            return false;
        }
    }
}
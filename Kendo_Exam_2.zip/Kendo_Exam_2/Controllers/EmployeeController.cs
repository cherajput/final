using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Kendo_Exam_2.Models;
using Microsoft.Extensions.Logging;
using Kendo_Exam_2.Repositories;

namespace Kendo_Exam_2.Controllers;

public class EmployeeController : Controller
{
    private readonly ILogger<EmployeeController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IEmployeeRepository _empRepo;

    public EmployeeController(ILogger<EmployeeController> logger, IUserRepository userRepository, IEmployeeRepository employeeRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _empRepo = employeeRepository;
    }
  
    
    [HttpGet]
    public IActionResult AddEmployee()
    {
        ViewBag.designations = _empRepo.GetAllDesignations();
        return View();
    }
    [HttpPost]
    public IActionResult AddEmployee(EmployeeModel emp)
    {
        _empRepo.AddEmployee(emp);
        return RedirectToAction("Index");
    }

    

     public IActionResult Index()
    {
        var emp = _empRepo.GetAllEmployees();
        ViewBag.designations = _empRepo.GetAllDesignations();

        return View(emp);
    }

    public IActionResult UpdateEmployee(int id)
    {
        ViewBag.designations = _empRepo.GetAllDesignations();
        var emp = _empRepo.GetEmployee(id);
        return View(emp);
    }

    [HttpPost]
    public IActionResult UpdateEmployee(EmployeeModel emp)
    {

        var salary = emp.c_gross_salary;
     
        var basic = salary * 60 / 100;
        var da = salary * 25 / 100;
       
        var hra = salary * 15 / 100;
      
        double tax;
        if (salary <= 25000)
        {
            tax = 0;
        }
        else
        {
            tax = salary * 10 / 100;
        }
        var takehome = basic + hra + da - tax;
        var taxableSalary = salary - basic;

        var pay = new PayrollModel
        {
            c_employee = emp.c_id,
            c_basic = basic,
            c_da = da,
            c_hra = hra,
            c_taxable_salary = taxableSalary,
            c_tax = tax,
            c_take_home = takehome
        };

        _empRepo.UpdatePayroll(pay);
        _empRepo.UpdateEmployee(emp);
        return RedirectToAction("Index");
    }

    public IActionResult DeleteEmployee(int id)
    {
        _empRepo.DeleteEmployee(id);
        return RedirectToAction("Index");
    }

    public IActionResult Payroll(int id)
    {
        var payroll = new PayrollModel();
        ViewBag.designations = _empRepo.GetAllDesignations();
        if (_empRepo.IsPayroll(id))
        {
            payroll = _empRepo.GetPayroll(id);
            var emp = _empRepo.GetEmployee(id);
            ViewBag.emp = emp;

            return View(payroll);
        }
        else
        {

            var emp = _empRepo.GetEmployee(id);
            ViewBag.emp = emp;
            var salary = emp.c_gross_salary;
           
            var basic = salary * 60 / 100;
            var da = salary * 25 / 100;
            var hra = salary * 15 / 100;
           
            double tax;
            if (salary <= 25000)
            {
                tax = 0;
            }
            else
            {
                tax = salary * 10 / 100;
            }
            var takehome = basic + hra + da - tax;
            var taxableSalary = salary - basic;

            var pay = new PayrollModel
            {
                c_employee = id,
                c_basic = basic,
                c_da = da,
                c_hra = hra,
                c_taxable_salary = taxableSalary,
                c_tax = tax,
                c_take_home = takehome
            };

            _empRepo.AddPayroll(pay);

            payroll = _empRepo.GetPayroll(id);
            return View(payroll);
        }

    }
    

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

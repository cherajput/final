using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Kendo_Exam_2.Models;
using Microsoft.Extensions.Logging;
using Kendo_Exam_2.Repositories;

namespace Kendo_Exam_2.Controllers;

public class UserController : Controller
{
    private readonly ILogger<UserController> _logger;
    private readonly IUserRepository _userRepository;

    public UserController(ILogger<UserController> logger, IUserRepository userRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
    }
    
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(UserModel login)
    {
        if (_userRepository.Login(login))
        {
            return RedirectToAction("Index", "Employee");
        }
        else
        {
            return RedirectToAction("Index", "Employee");
        }
    }

    public IActionResult Privacy()
    {
        return View();
    }
    

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

namespace Kendo_Exam_2.Models;

public class EmployeeModel
{
    public int c_id { get; set; }
    public string c_name { get; set; }
    public DateTime c_hire_date { get; set; }
    public float c_gross_salary { get; set; }
    public int c_designation { get; set; }
    public string c_gender { get; set; }
}
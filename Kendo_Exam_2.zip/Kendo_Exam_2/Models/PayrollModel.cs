namespace Kendo_Exam_2.Models;
public class PayrollModel
{
    public int c_id { get; set; }
    public int c_employee { get; set; }
    public double c_basic { get; set; }
    public double c_da { get; set; }
    public double c_hra { get; set; }
    public double c_taxable_salary { get; set; }
    public double c_tax { get; set; }
    public double c_take_home { get; set; }
}
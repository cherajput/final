using Npgsql;
using Kendo_Exam_2.Models;

namespace Kendo_Exam_2.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor access;

        public EmployeeRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            _conn = config.GetConnectionString("Kali");
            conn = new NpgsqlConnection(_conn);
            access = accessor;
        }

        public void AddEmployee(EmployeeModel emp)
        {
            try
            {
                conn.Open();
                var query = "insert into t_employee(c_name,c_hire_date,c_gross_salary,c_designation,c_gender) values(@n,@h,@g,@d,@ge)";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@n", emp.c_name);
                command.Parameters.AddWithValue("@h", emp.c_hire_date);
                command.Parameters.AddWithValue("@g", emp.c_gross_salary);
                command.Parameters.AddWithValue("@d", emp.c_designation);
                command.Parameters.AddWithValue("@ge", emp.c_gender);
                command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public List<DesignationModel> GetAllDesignations()
        {
            try
            {
                conn.Open();
                var query = "select * from t_designation";
                var command = new NpgsqlCommand(query, conn);
                var reader = command.ExecuteReader();
                List<DesignationModel> desigs = new List<DesignationModel>();
                while (reader.Read())
                {
                    desigs.Add(new DesignationModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                    });

                }
                return desigs;

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }
        public List<EmployeeModel> GetAllEmployees()
        {
            try
            {
                conn.Open();
                var query = "select * from t_employee order by c_id asc";
                var command = new NpgsqlCommand(query, conn);
                var reader = command.ExecuteReader();
                List<EmployeeModel> emps = new List<EmployeeModel>();
                while (reader.Read())
                {
                    emps.Add(new EmployeeModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_hire_date = reader.GetDateTime(2),
                        c_gross_salary = reader.GetFloat(3),
                        c_designation = reader.GetInt32(4),
                        c_gender = reader.GetString(5),
                    });

                }
                return emps;

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public EmployeeModel GetEmployee(int id)
        {
            try
            {
                conn.Open();
                var query = "select * from t_employee where c_id=@i";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@i", id);
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return new EmployeeModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_hire_date = reader.GetDateTime(2),
                        c_gross_salary = reader.GetFloat(3),
                        c_designation = reader.GetInt32(4),
                        c_gender = reader.GetString(5),
                    };
                }

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public void UpdateEmployee(EmployeeModel emp)
        {
            try
            {
                conn.Open();
                var query = "update t_employee set c_name=@n,c_hire_date=@h,c_gross_salary=@g,c_designation=@d,c_gender=@ge where c_id=@i";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@n", emp.c_name);
                command.Parameters.AddWithValue("@h", emp.c_hire_date);
                command.Parameters.AddWithValue("@g", emp.c_gross_salary);
                command.Parameters.AddWithValue("@d", emp.c_designation);
                command.Parameters.AddWithValue("@ge", emp.c_gender);
                command.Parameters.AddWithValue("@i", emp.c_id);
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }


         public void DeleteEmployee(int id)
        {
            try
            {
                conn.Open();
                var query = "delete from t_employee where c_id=@i";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@i", id);
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

         public void AddPayroll(PayrollModel pay)
        {
            try
            {
                conn.Open();
                //fields c_employee,c_basic,c_da,c_hra,c_taxable_salary,c_tax,c_take_home
                var query = "insert into t_payroll(c_employee,c_basic,c_da,c_hra,c_tax,c_taxable_salary,c_take_home) values(@i,@b,@d,@h,@t,@ta,@th)";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@i", pay.c_employee);
                command.Parameters.AddWithValue("@b", pay.c_basic);
                command.Parameters.AddWithValue("@d", pay.c_da);
                command.Parameters.AddWithValue("@h", pay.c_hra);
                command.Parameters.AddWithValue("@t", pay.c_tax);
                command.Parameters.AddWithValue("@ta", pay.c_taxable_salary);
                command.Parameters.AddWithValue("@th", pay.c_take_home);
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public PayrollModel GetPayroll(int id)
        {
            try
            {
                conn.Open();
                var query = "select * from t_payroll where c_employee=@i";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@i", id);
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return new PayrollModel
                    {
                        c_id = reader.GetInt32(0),
                        c_employee = reader.GetInt32(1),
                        c_basic = reader.GetFloat(2),
                        c_da = reader.GetFloat(3),
                        c_hra = reader.GetFloat(4),
                        c_taxable_salary = reader.GetFloat(5),
                        c_tax = reader.GetFloat(6),
                        c_take_home = reader.GetFloat(7),
                    };
                }

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public bool IsPayroll(int id)
        {
            try
            {
                conn.Open();
                var query = "select * from t_payroll where c_employee=@i";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@i", id);
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return true;
                }

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        public void UpdatePayroll(PayrollModel pay)
        {
            try
            {
                conn.Open();
                var query = "update t_payroll set c_basic=@b,c_da=@d,c_hra=@h,c_taxable_salary=@ta,c_tax=@t,c_take_home=@th where c_employee=@i";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@b", pay.c_basic);
                command.Parameters.AddWithValue("@d", pay.c_da);
                command.Parameters.AddWithValue("@h", pay.c_hra);
                command.Parameters.AddWithValue("@t", pay.c_tax);
                command.Parameters.AddWithValue("@ta", pay.c_taxable_salary);
                command.Parameters.AddWithValue("@th", pay.c_take_home);
                command.Parameters.AddWithValue("@i", pay.c_employee);
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

    }
}
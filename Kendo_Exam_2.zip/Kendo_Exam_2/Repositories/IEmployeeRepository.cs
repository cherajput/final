using Kendo_Exam_2.Models;

namespace Kendo_Exam_2.Repositories
{
    public interface IEmployeeRepository
    {
         public void AddEmployee(EmployeeModel emp);
         public List<DesignationModel> GetAllDesignations();
         public List<EmployeeModel> GetAllEmployees();
         public EmployeeModel GetEmployee(int id);
         public void UpdateEmployee(EmployeeModel emp);
         public void DeleteEmployee(int id);
         public void AddPayroll(PayrollModel pay);
         public PayrollModel GetPayroll(int id);
         public bool IsPayroll(int id);
         public void UpdatePayroll(PayrollModel pay);

    }
}
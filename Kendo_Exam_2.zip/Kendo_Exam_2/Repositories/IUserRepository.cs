using Kendo_Exam_2.Models;


namespace Kendo_Exam_2.Repositories
{
    public interface IUserRepository
    {
        bool Login(UserModel login);
    }
}
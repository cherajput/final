using Npgsql;
using Kendo_Exam_2.Models;

namespace Kendo_Exam_2.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor access;

        public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            _conn = config.GetConnectionString("Kali");
            conn = new NpgsqlConnection(_conn);
            access = accessor;
        }

        public bool Login(UserModel login)
        {
           try
            {
                conn.Open();
                var query = "SELECT * FROM t_usermaster WHERE c_email = @c_email AND c_password = @c_password";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_email", login.c_email);
                cmd.Parameters.AddWithValue("@c_password", login.c_password);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string c_roles = reader["c_role"].ToString();
                    string c_password = reader["c_password"].ToString();

                   

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return true;
        }
    }
}
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;
using Repository.Models;

namespace mvc.Controllers;

public class CustomerController : Controller
{
    private readonly CustomerRepository repo;

    public CustomerController(CustomerRepository r)
    {
        repo = r;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult AddToken(CustomerTokenModel token)
    {
        int t = repo.AddToken(token);
        TempData["token"] = t;
        return RedirectToAction("index");
    }

    [HttpGet]
    public IActionResult Tokens()
    {
        var tokens = repo.GetAllTokens();
        return View(tokens);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

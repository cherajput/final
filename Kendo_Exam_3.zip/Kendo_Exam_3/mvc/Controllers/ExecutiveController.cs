using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;
using Repository.Models;

namespace mvc.Controllers;

public class ExecutiveController : Controller
{
    private readonly ExecutiveRepository repo;

    public ExecutiveController(ExecutiveRepository r)
    {
        repo = r;
    }

    public IActionResult Index()
    {
        var tokens = repo.GetTokens();
        return View(tokens);
    }
    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Login(ExecutiveLoginModel login)
    {
        if (repo.Login(login))
        {

            return RedirectToAction("index");
        }
        return View();
    }
    public IActionResult Resolve(int id)
    {
        var tokne = repo.GetTokenById(id);
        return View(tokne);
    }

    [HttpPost]
    public IActionResult Resolve(CustomerTokenModel token)
    {
        repo.Resolve(token);
        return RedirectToAction("index");
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

using Npgsql;
using Repository.Models;

namespace mvc.Repositories;
public class ExecutiveRepository
{
    private string conn;
    private IHttpContextAccessor access;

    public ExecutiveRepository(IConfiguration config, IHttpContextAccessor acc)
    {
        conn = config.GetConnectionString("a");
        access = acc;
    }

    public bool Login(ExecutiveLoginModel ex)
    {

        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_password,c_type from t_executive_login where c_id = @id and c_password = @pass";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", ex.c_id);
                comm.Parameters.AddWithValue("@pass", ex.c_password);
                var reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    access.HttpContext.Session.SetString("type", reader.GetString(2));
                    return true;

                }
                else
                {
                    return false;
                }

            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return false;
    }

    public List<CustomerTokenModel> GetTokens()
    {

        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_token_id,c_token_type,c_status from t_customer_token where c_token_type=@type";
                var comm = new NpgsqlCommand(query, con);
                var type = access.HttpContext.Session.GetString("type");
                comm.Parameters.AddWithValue("@type", type);
                var reader = comm.ExecuteReader();
                var tokens = new List<CustomerTokenModel>();
                while (reader.Read())
                {
                    var token = new CustomerTokenModel
                    {
                        c_id = reader.GetInt32(0),
                        c_token_id = reader.GetInt32(1),
                        c_token_type = reader.GetString(2),
                        c_status = reader.GetString(3)
                    };
                    tokens.Add(token);
                }
                return tokens;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }
    public CustomerTokenModel GetTokenById(int id)
    {

        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_token_id,c_token_type,c_status from t_customer_token where c_id=@id";
                var comm = new NpgsqlCommand(query, con);
                var type = access.HttpContext.Session.GetString("type");
                comm.Parameters.AddWithValue("@id", id);
                var reader = comm.ExecuteReader();
                var tokens = new CustomerTokenModel();
                if (reader.Read())
                {

                    tokens.c_id = reader.GetInt32(0);
                    tokens.c_token_id = reader.GetInt32(1);
                    tokens.c_token_type = reader.GetString(2);
                    tokens.c_status = reader.GetString(3);


                    return tokens;
                }
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void Resolve(CustomerTokenModel token)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "update t_customer_token set c_customer_name = @name, c_customer_phone=@phone, c_status='Resolved' where c_id = @id";
                var comm = new NpgsqlCommand(query,con);
                comm.Parameters.AddWithValue("@name", token.c_customer_name);
                comm.Parameters.AddWithValue("@phone", token.c_customer_phone);
                comm.Parameters.AddWithValue("@id", token.c_id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

}
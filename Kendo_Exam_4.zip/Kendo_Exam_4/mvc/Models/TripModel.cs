namespace mvc.Models
{
    public class TripModel
    {
        //c_id,c_trip,c_price,c_ticket_stock,c_current_stock
        public int? c_id { get; set; }
        public string c_trip { get; set; }
        public string? c_price { get; set; }
        public int? c_ticket_stock { get; set; }
        public int? c_current_stock { get; set; }

    }
}
Customer(Id, Password)
Viraj = 1234

Admin(Id, Password)
Rajvardhan = 1234

Everything Working

Feature Note : In AddToCart On photo click and Addtocart button both working as a AddToCart Function
using Repository.Models;

namespace Repository.Repository
{
    public interface IAdminRepository
    {
        List<AlbumModel> GetAlbums();
        void AddAlbum(AlbumModel albumModel);
        void UpdateAlbum(AlbumModel albumModel);
        void DeleteAlbum(int id);
        AlbumModel GetAlbumById(int id);

        List<GraphModel> GetGenre();
        List<RevenueModel> GetRevenue();
        List<RevenueModel> GetWeeklyRevenue();
        List<RevenueModel> GetMonthRevenue();


        void CheckoutDetails(CheckoutModel checkoutModel);


        void RemoveFromCart(int id);

        List<CartModel> GetAllCart();

        void AddToCart(CartModel cartModel);






    }
}

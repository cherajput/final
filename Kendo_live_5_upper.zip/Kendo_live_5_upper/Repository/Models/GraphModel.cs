namespace Repository.Models
{

    public class GraphModel
    {
        public string name { get; set; }
        public int value { get; set; }
    }

}
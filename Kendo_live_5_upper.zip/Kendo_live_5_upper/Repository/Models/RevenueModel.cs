namespace Repository.Models
{
    public class RevenueModel
    {
        public DateTime c_date { get; set; }
        public int c_sales { get; set; }
        public int c_revenue { get; set; }
    }
}
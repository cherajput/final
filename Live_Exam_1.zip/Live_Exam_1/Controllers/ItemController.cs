using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;
namespace mvc.Controllers;

public class ItemController : Controller
{
    private readonly IUserRepository userRepository;
    private readonly IItemRepository itemRepository;
    private readonly IPurchaseRepository purchaseRepository;
    private readonly IWebHostEnvironment _environment;
    // private readonly ITaskRepository taskRepository;
    public ItemController(IUserRepository userRepository, IItemRepository itemRepository, IPurchaseRepository purchaseRepository, IWebHostEnvironment _environment)
    {
        this.userRepository = userRepository;
        this.purchaseRepository = purchaseRepository;
        this._environment = _environment;
        this.itemRepository = itemRepository;

        // this.taskRepository = taskRepository;
    }

    [HttpGet]
    public IActionResult PurchasedItem()
    {
        var item = TempData["PurchaseItem"];

        return View(item);
    }

    [HttpGet]
    public IActionResult Update(int id)
    {
        var item = itemRepository.GetItemById(id);
        return View(item);

    }

    [HttpPost]
    public IActionResult Update(Item item)
    {

        var olditem = itemRepository.GetItemById(item.c_id);
        if (item.Image != null && item.Image.Length > 0)
        {
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var uniqueFileName = Guid.NewGuid().ToString() + "_" + item.Image.FileName;
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                item.Image.CopyTo(stream);
            }

            item.c_image = uniqueFileName; // Save the file name to the database
        }
        else
        {
            item.c_image = olditem.c_image;
        }

        itemRepository.UpdateItem(item);
        return RedirectToAction("index", "user");
    }

    [HttpGet]
    public IActionResult Delete(int id)
    {
        itemRepository.DeleteItem(id);
        return RedirectToAction("index", "user");
    }

    public IActionResult UserPurchasedItem()
    {
        if (HttpContext.Session.GetString("username") == null)
        {
            return RedirectToAction("login", "user");
        }
        var items = purchaseRepository.GetPurchases();
        return View(items);
    }

    [HttpPost]
    public IActionResult PurchasedItem([FromBody] purchase item)
    {
        purchaseRepository.AddPurchase(item);
        return Ok("success");
    }


    public IActionResult Index()
    {
        if (HttpContext.Session.GetString("username") == null)
        {
            return RedirectToAction("login", "user");
        }

        var items = itemRepository.GetItems();
        return View(items);
    }

    public IActionResult AddItem()
    {
        return View();
    }

    [HttpPost]
    public IActionResult AddItem(Item item)
    {
        if (item.Image != null && item.Image.Length > 0)
        {
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var uniqueFileName = Guid.NewGuid().ToString() + "_" + item.Image.FileName;
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                item.Image.CopyTo(stream);
            }

            item.c_image = uniqueFileName; // Save the file name to the database
        }

        itemRepository.AddItem(item);
        return RedirectToAction("Index", "user"); // Redirect to home page or any other action
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using mvc.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using mvc.Models;

namespace first.Controllers
{
    // [Route("[controller]")]
    public class UserController : Controller
    {

        private readonly IUserRepository userRepository;
        private readonly IItemRepository itemRepository;
        public UserController(IUserRepository userRepository, IItemRepository itemRepository)
        {
            this.userRepository = userRepository;
            this.itemRepository = itemRepository;
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserMaster user)
        {

            if (userRepository.IsUser(user.c_email))
            {
                ViewBag.msg = "*User already exist please use different email address";
                return View();

            }
            else
            {
                TempData["smsg"] = "Your are successfully registered login to continue";
                userRepository.AddUser(user);
                return RedirectToAction("login");
            }

        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(UserMaster user)
        {
            if (userRepository.Login(user))
            {

                if (HttpContext.Session.GetString("userrole") == "admin")
                {
                    return RedirectToAction("index", "User");
                }
                else
                {

                    return RedirectToAction("index", "item");
                }
            }
            TempData["msg"] = "Username or password is wrong";

            return View();
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("username");
            return RedirectToAction("login");
        }

        public IActionResult Index()
        {
            // List<String> userTasks = userRepository.GetTasksByUserId();
            // if (HttpContext.Session.GetString("userrole") == "user")
            // {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "user");
            }
            var items = itemRepository.GetItems();
            return View(items);
            // }
            // else
            // {
            //     return RedirectToAction("Login", "user");
            // }

        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}
using mvc.Models;
namespace mvc.Repositories
{
    public interface IItemRepository
    {
        public void AddItem(Item item);
        public List<Item> GetItems();
        public Item GetItemById(int id);
        public void UpdateItem(Item item);
        public void DeleteItem(int id);
    }
}
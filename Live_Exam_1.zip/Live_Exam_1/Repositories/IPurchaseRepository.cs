using mvc.Models;
namespace mvc.Repositories

{
    public interface IPurchaseRepository
    {
        public void AddPurchase(purchase purchase);
        public List<purchase> GetPurchases();
        public purchase GetPurchaseById(int id);
        // public void UpdatePurchase(purchase purchase);
        // public void DeletePurchase(int id);
    }
}
using mvc.Models;
namespace mvc.Repositories;

public interface IUserRepository
{
    public void AddUser(UserMaster user);
    public bool IsUser(string email);
    public bool Login(UserMaster user);
    public bool VerifyPassword(string storedHash, string providedPassword);
    public List<String> GetTasksByUserId();

    public string GetTaskNameById(int id);


}
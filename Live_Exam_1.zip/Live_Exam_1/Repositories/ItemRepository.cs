using mvc.Models;
using Npgsql;
namespace mvc.Repositories;
public class ItemRepository : IItemRepository
{
    private readonly string _conn;
    private readonly NpgsqlConnection conn;
    // private NpgsqlConnection connForTask;
    private readonly IHttpContextAccessor access;
    public ItemRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        _conn = config.GetConnectionString("GroupA");
        conn = new NpgsqlConnection(_conn);
        // connForTask = new NpgsqlConnection(_conn);
        access = accessor;
    }

    public void AddItem(Item item)
    {

        try
        {
            conn.Open();
            string query = "insert into public.t_items(c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock) values(@n,@c,@i,@cp,@is,@as)";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@n", item.c_name);
            command.Parameters.AddWithValue("@c", item.c_category);
            command.Parameters.AddWithValue("@i", item.c_image);
            command.Parameters.AddWithValue("@cp", item.c_cost_per_unit);
            command.Parameters.AddWithValue("@is", item.c_initial_stock);
            command.Parameters.AddWithValue("@as", item.c_available_stock);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public void DeleteItem(int id)
    {
        try
        {
            conn.Open();
            string query = "delete from public.t_items where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public Item GetItemById(int id)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_items where c_id =" + id;
            var command = new NpgsqlCommand(query, conn);
            var reader = command.ExecuteReader();
            reader.Read();
            Item item = new Item();
            item.c_id = reader.GetInt32(0);
            item.c_name = reader.GetString(1);
            item.c_category = reader.GetString(2);
            item.c_image = reader.GetString(3);
            item.c_cost_per_unit = reader.GetInt32(4);
            item.c_initial_stock = reader.GetInt32(5);
            item.c_available_stock = reader.GetInt32(6);
            return item;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return null;
        }
        finally
        {
            conn.Close();
        }
    }

    public List<Item> GetItems()
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_items";
            var command = new NpgsqlCommand(query, conn);
            var reader = command.ExecuteReader();
            List<Item> items = new List<Item>();
            while (reader.Read())
            {
                Item item = new Item();
                item.c_id = reader.GetInt32(0);
                item.c_name = reader.GetString(1);
                item.c_category = reader.GetString(2);
                item.c_image = reader.GetString(3);
                item.c_cost_per_unit = reader.GetInt32(4);
                item.c_initial_stock = reader.GetInt32(5);
                item.c_available_stock = reader.GetInt32(6);
                items.Add(item);
            }
            return items;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return null;
        }
        finally
        {
            conn.Close();
        }
    }



    public void UpdateItem(Item item)
    {
        try
        {
            conn.Open();
            string query = "update public.t_items set c_name=@n,c_category=@c,c_image=@i,c_cost_per_unit=@cp,c_initial_stock=@is,c_available_stock=@as where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@n", item.c_name);
            command.Parameters.AddWithValue("@c", item.c_category);
            command.Parameters.AddWithValue("@i", item.c_image);
            command.Parameters.AddWithValue("@cp", item.c_cost_per_unit);
            command.Parameters.AddWithValue("@is", item.c_initial_stock);
            command.Parameters.AddWithValue("@as", item.c_available_stock);
            command.Parameters.AddWithValue("@id", item.c_id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }
}
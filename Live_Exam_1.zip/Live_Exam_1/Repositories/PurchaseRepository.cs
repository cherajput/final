using Npgsql;
using mvc.Models;
using Microsoft.AspNetCore.Identity;

namespace mvc.Repositories;

public class PurchaseRepository : IPurchaseRepository
{
    private readonly string _conn;
    private readonly NpgsqlConnection conn;
    private NpgsqlConnection connForTask;
    private readonly IHttpContextAccessor access;
    public PurchaseRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        _conn = config.GetConnectionString("GroupA");
        conn = new NpgsqlConnection(_conn);
        connForTask = new NpgsqlConnection(_conn);
        access = accessor;
    }

    public void AddPurchase(purchase purchase)
    {

        try
        {
            conn.Open();

            string query = "insert into public.t_purchase(c_item_id,c_quantity,c_total_cost,c_cost_per_unit,c_user_id) values(@i,@q,@t,@d,@c)";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@i", purchase.c_item_id);
            command.Parameters.AddWithValue("@q", purchase.c_quantity);
            command.Parameters.AddWithValue("@t", purchase.c_total_cost);
            command.Parameters.AddWithValue("@d", purchase.c_cost_per_unit);
            var userid = access.HttpContext.Session.GetInt32("userid");
            command.Parameters.AddWithValue("@c", userid);

            // command.Parameters.AddWithValue("@d", purchase.c_date);

            command.ExecuteNonQuery();
            connForTask.Open();
            //remove stock from item table
            string query1 = "update public.t_items set c_available_stock = c_available_stock - @q where c_id = @i";
            var command1 = new NpgsqlCommand(query1, connForTask);
            command1.Parameters.AddWithValue("@i", purchase.c_item_id);
            command1.Parameters.AddWithValue("@q", purchase.c_quantity);
            command1.ExecuteNonQuery();

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
            connForTask.Close();
        }
    }

    public List<purchase> GetPurchases()
    {
        try
        {
            conn.Open();
            var userid = access.HttpContext.Session.GetInt32("userid");
            string query = "SELECT p.c_id, p.c_cost_per_unit, p.c_item_id, p.c_quantity, p.c_total_cost, i.c_name AS item_name " +
                           "FROM public.t_purchase p " +
                           "INNER JOIN public.t_items i ON p.c_item_id = i.c_id " +
                           "WHERE p.c_user_id = @userid";

            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@userid", userid);
            var reader = command.ExecuteReader();
            List<purchase> purchases = new List<purchase>();
            while (reader.Read())
            {
                purchase purchase = new purchase();
                purchase.c_id = Convert.ToInt32(reader["c_id"]);
                purchase.c_cost_per_unit = Convert.ToInt32(reader["c_cost_per_unit"]);
                purchase.c_item_id = Convert.ToInt32(reader["c_item_id"]);
                purchase.c_quantity = Convert.ToInt32(reader["c_quantity"]);
                purchase.c_total_cost = Convert.ToInt32(reader["c_total_cost"]);
                purchase.c_item_name = Convert.ToString(reader["item_name"]);

                purchases.Add(purchase);
            }
            return purchases;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return null;
        }
        finally
        {
            conn.Close();
        }
    }


    public purchase GetPurchaseById(int id)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_purchase where xxxxx@xx";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            var reader = command.ExecuteReader();
            purchase purchase = new purchase();
            while (reader.Read())
            {
                purchase.c_id = reader.GetInt32(0);
                purchase.c_item_id = reader.GetInt32(1);
                purchase.c_quantity = reader.GetInt32(2);
                purchase.c_total_cost = reader.GetInt32(3);
                // purchase.c_date = reader.GetDateTime(4);
            }
            return purchase;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return null;
        }
        finally
        {
            conn.Close();
        }
    }
}
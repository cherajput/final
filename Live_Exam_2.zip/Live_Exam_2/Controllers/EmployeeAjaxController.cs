using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class EmployeeAjaxController : Controller
{

    private readonly IEmployeeRepository _empRepo;
    public EmployeeAjaxController(IEmployeeRepository rep)
    {
        _empRepo = rep;
    }


    public IActionResult Index()
    {

        return View();
    }

    public IActionResult GetEmployee()
    {
        var emp = _empRepo.GetAllEmployees();
        return Json(emp);
    }

    public IActionResult AddEmployee()
    {
        ViewBag.designations = _empRepo.GetAllDesignations();
        return View();
    }
    [HttpPost]
    public IActionResult AddEmployee(EmployeeModel emp)
    {
        _empRepo.AddEmployee(emp);
        return RedirectToAction("Index");
    }

    public IActionResult UpdateEmployee(int id)
    {
        ViewBag.designations = _empRepo.GetAllDesignations();
        var emp = _empRepo.GetEmployee(id);
        return View(emp);
    }

    [HttpPost]
    public IActionResult UpdateEmployee(EmployeeModel emp)
    {

        var salary = emp.c_gross_salary;
        var basic = salary * 60 / 100;
        var da = salary * 25 / 100;
        var hra = salary * 15 / 100;

        double tax;
        if (salary <= 25000)
        {
            tax = 0;
        }
        else
        {
            tax = salary * 10 / 100;
        }
        var takehome = basic + hra + da - tax;
        var taxableSalary = salary - basic;

        var pay = new PayrollModel
        {
            c_employee = emp.c_id,
            c_basic = basic,
            c_da = da,
            c_hra = hra,
            c_taxable_salary = taxableSalary,
            c_tax = tax,
            c_take_home = takehome
        };

        _empRepo.UpdatePayroll(pay);
        _empRepo.UpdateEmployee(emp);
        return Ok("Index");
    }

    public IActionResult DeleteEmployee(int id)
    {
        _empRepo.DeleteEmployee(id);
        return Json("Index");
    }

    public static int id;
    public IActionResult Payroll(int i)
    {
        id = i;
        var emp = _empRepo.GetEmployee(id);
        ViewBag.designations = _empRepo.GetAllDesignations();
        ViewBag.emp = emp;
        return View();
    }

    [HttpPost]
    public IActionResult Payroll()
    {
        var payroll = new PayrollModel();
        if (_empRepo.IsPayroll(id))
        {
            payroll = _empRepo.GetPayroll(id);


            return Json(payroll);
        }
        else
        {

            var emp = _empRepo.GetEmployee(id);

            var salary = emp.c_gross_salary;

            var basic = salary * 60 / 100;

            var da = salary * 25 / 100;
            var hra = salary * 15 / 100;

            double tax;
            if (salary <= 25000)
            {
                tax = 0;
            }
            else
            {
                tax = salary * 10 / 100;
            }
            var takehome = basic + hra + da - tax;
            var taxableSalary = salary - basic;

            var pay = new PayrollModel
            {
                c_employee = id,
                c_basic = basic,
                c_da = da,
                c_hra = hra,
                c_taxable_salary = taxableSalary,
                c_tax = tax,
                c_take_home = takehome
            };

            _empRepo.AddPayroll(pay);

            payroll = _empRepo.GetPayroll(id);
            return Json(payroll);
        }

    }

    public IActionResult Privacy()
    {
        return View();
    }


}

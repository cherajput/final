using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;
namespace mvc.Controllers;

public class UserController : Controller
{
    private IUserRepository _userRepo;
    public UserController(IUserRepository rep)
    {
        _userRepo = rep;

    }

    public IActionResult Register()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Register(UserModel user)
    {
        _userRepo.Register(user);
        return RedirectToAction("login");
    }

    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Login(UserModel user)
    {
        if (_userRepo.Login(user))
        {
            return RedirectToAction("Index", "employee");
        }
        else
        {
            ViewBag.msg = "email or password is wrong";
            return View();
        }
    }


    public IActionResult IsUser(string email)
    {
        UserModel u = new UserModel();
        u.c_email = email;
        if (_userRepo.IsUser(u))
        {
            return Ok("exist");
        }
        else
        {
            return Ok("notexist");
        }
    }
}
using mvc.Models;
namespace mvc.Repositories;

public interface IEmployeeRepository
{
    public void AddEmployee(EmployeeModel emp);
    public void UpdateEmployee(EmployeeModel emp);
    public void DeleteEmployee(int id);
    public List<EmployeeModel> GetAllEmployees();
    public EmployeeModel GetEmployee(int id);
    List<DesignationModel> GetAllDesignations();
    public void AddPayroll(PayrollModel pay);
    public PayrollModel GetPayroll(int id);

    public bool IsPayroll(int id);
    public void UpdatePayroll(PayrollModel pay);
}
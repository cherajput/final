using mvc.Models;

namespace mvc.Repositories;
public interface IUserRepository{
    void Register(UserModel user);
    bool Login(UserModel user);
    bool IsUser(UserModel user);
}
using mvc.Models;
using mvc.Repositories;
using Npgsql;

namespace mvc.Repositories;
public class UserRepository : IUserRepository
{
    private readonly NpgsqlConnection conn;
    private readonly IHttpContextAccessor accessor;
    public UserRepository(IConfiguration config, IHttpContextAccessor acc)
    {
        conn = new NpgsqlConnection(config.GetConnectionString("Aubergine"));
        accessor = acc;
    }
    public bool IsUser(UserModel user)
    {
        try
        {
            conn.Open();
            var query = "select * from t_usermaster where c_email=@e";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@e", user.c_email);
            var reader = command.ExecuteReader();
            if (reader.Read())
            {

                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return false;
    }

    public bool Login(UserModel user)
    {
        try
        {
            conn.Open();
            var query = "select * from t_usermaster where c_email=@e and c_password = @p";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@e", user.c_email);
            command.Parameters.AddWithValue("@p", user.c_password);
            var reader = command.ExecuteReader();
            if (reader.Read())
            {
                accessor.HttpContext.Session.SetString("username", reader["c_username"].ToString());

                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return false;
    }

    public void Register(UserModel user)
    {
        try
        {
            conn.Open();
            string query = "insert into t_usermaster(c_username,c_password,c_email,c_role) values (@u,@p,@e,'user')";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@u", user.c_username);
            command.Parameters.AddWithValue("@p", user.c_password);
            command.Parameters.AddWithValue("@e", user.c_email);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();

        }

    }
}
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mvc.Models;
using Repository.Interfaces;
using Repository.Models;

namespace Mvc.Controllers;

public class CustomerToken : Controller
{
    private readonly ILogger<CustomerToken> _logger;
    private readonly ICustomerTokenRepository _customerTokenRepository;
    public CustomerToken(ILogger<CustomerToken> logger, ICustomerTokenRepository customerTokenRepository)
    {
        _logger = logger;
        _customerTokenRepository = customerTokenRepository;
    }


    public IActionResult Index()
    {
        return View();
    }

    public IActionResult AddToken()
    {
        // ViewBag.Token = token;
        return View();
    }
    public static int token;
    [HttpPost]
    public IActionResult AddToken(CustomerTokenModel customerTokenModel)
    {
        token = _customerTokenRepository.AddToken(customerTokenModel);
        TempData["Token"] = token;
        return View();
    }

    public IActionResult GetTokens()
    {
        List<CustomerTokenModel> customerTokenModels = _customerTokenRepository.GetTokens();
        return View(customerTokenModels);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

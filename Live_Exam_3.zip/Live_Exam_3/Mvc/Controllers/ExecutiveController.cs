using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mvc.Models;
using Repository.Interfaces;
using Repository.Models;

namespace Mvc.Controllers;

public class ExecutiveController : Controller
{
    private readonly ILogger<ExecutiveController> _logger;
    private readonly IExecutiveRepository _ExecutiveRepository;
    private readonly ICustomerTokenRepository _customerTokenRepository;
    public ExecutiveController(ILogger<ExecutiveController> logger, IExecutiveRepository ecustomerTokenRepository, ICustomerTokenRepository customerTokenRepository)
    {
        _logger = logger;
        _ExecutiveRepository = ecustomerTokenRepository;
        _customerTokenRepository = customerTokenRepository;
    }


    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(ExecutiveLoginModel executiveLoginModel)
    {
        if (_ExecutiveRepository.ExecutiveLogin(executiveLoginModel))
        {

            return RedirectToAction("GetTokens");
        }
        else
        {
            ViewBag.Message = "Invalid Credentials";
            return View();
        }

    }

    public IActionResult GetTokens()
    {
        List<CustomerTokenModel> customerTokenModels = _ExecutiveRepository.GetTokens();
        return View(customerTokenModels);
    }

    public IActionResult Resolve(int id)
    {
        CustomerTokenModel customerTokenModel = _customerTokenRepository.GetToken(id);
        // customerTokenModel.c_status = "Resolved";
        // _customerTokenRepository.UpdateTokenStatus(customerTokenModel);
        return View(customerTokenModel);
    }

    [HttpPost]
    public IActionResult Resolve(CustomerTokenModel customerTokenModel)
    {
        _customerTokenRepository.UpdateTokenStatus(customerTokenModel);
        return RedirectToAction("GetTokens");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

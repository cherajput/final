﻿namespace Repository;
public class Class1
{

}

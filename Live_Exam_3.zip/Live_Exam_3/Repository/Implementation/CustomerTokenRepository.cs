using Microsoft.AspNetCore.Http;
using Npgsql;
using Microsoft.Extensions.Configuration;
using Repository.Models;
using Repository.Interfaces;
namespace Repository.Implementation;
public class CustomerTokenRepository : ICustomerTokenRepository
{
    private readonly NpgsqlConnection conn;
    public CustomerTokenRepository(IConfiguration configuration)
    {
        conn = new NpgsqlConnection(configuration.GetConnectionString("DefaultConnection"));
    }

    public int AddToken(CustomerTokenModel customerTokenModel)
    {
        int insertedId = 0;
        conn.Open();
        using (var cmd = new NpgsqlCommand())
        {
            cmd.Connection = conn;
            cmd.CommandText = "INSERT INTO t_customer_token(c_token_type,c_status) VALUES(@c_token_type,@c_status) RETURNING c_token_id";
            cmd.Parameters.AddWithValue("c_token_type", customerTokenModel.c_token_type);
            cmd.Parameters.AddWithValue("c_status", "Pending");
            // insertedId = Convert.ToInt32(cmd.ExecuteScalar());
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    insertedId = Convert.ToInt32(result);
                }
        }
        conn.Close();
        return insertedId;
    }

    public void UpdateTokenStatus(CustomerTokenModel customerTokenModel)
    {
        conn.Open();
        using (var cmd = new NpgsqlCommand())
        {
            cmd.Connection = conn;
            cmd.CommandText = "UPDATE t_customer_token SET c_status='Resolved', c_customer_name=@n, c_customer_phone=@p  WHERE c_token_id=@c_token_id";
            cmd.Parameters.AddWithValue("c_token_id", customerTokenModel.c_token_id);
            cmd.Parameters.AddWithValue("n", customerTokenModel.c_customer_name);
            cmd.Parameters.AddWithValue("p", customerTokenModel.c_customer_phone);
            cmd.ExecuteNonQuery();
        }
        conn.Close();
    }

    public CustomerTokenModel GetToken(int id)
    {
        CustomerTokenModel customerTokenModel = new CustomerTokenModel();
        conn.Open();
        using (var cmd = new NpgsqlCommand())
        {
            cmd.Connection = conn;
            cmd.CommandText = "SELECT * FROM t_customer_token WHERE c_token_id=@c_token_id";
            cmd.Parameters.AddWithValue("c_token_id", id);
            var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                customerTokenModel.c_id = reader.GetInt32(0);
                customerTokenModel.c_token_id = reader.GetInt32(1);
                customerTokenModel.c_token_type = reader.GetString(2);
                customerTokenModel.c_status = reader.GetString(3);

            }
        }
        conn.Close();
        return customerTokenModel;
    }

    public List<CustomerTokenModel> GetTokens()
    {
        List<CustomerTokenModel> customerTokenModels = new List<CustomerTokenModel>();
        conn.Open();
        using (var cmd = new NpgsqlCommand())
        {
            cmd.Connection = conn;
            cmd.CommandText = "SELECT * FROM t_customer_token where c_status = 'Pending'";
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                CustomerTokenModel customerTokenModel = new CustomerTokenModel();
                customerTokenModel.c_id = reader.GetInt32(0);
                customerTokenModel.c_token_id = reader.GetInt32(1);
                customerTokenModel.c_token_type = reader.GetString(2);
                customerTokenModel.c_status = reader.GetString(3);
                // customerTokenModel.c_customer_name = reader.GetString(4);
                // customerTokenModel.c_customer_phone = reader.GetString(5);
                customerTokenModels.Add(customerTokenModel);
            }
        }
        conn.Close();
        return customerTokenModels;
    }
}
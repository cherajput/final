using Microsoft.AspNetCore.Http;
using Npgsql;
using Microsoft.Extensions.Configuration;
using Repository.Models;
using Repository.Interfaces;
using Microsoft.AspNetCore.Session;



namespace Repository.Implementation
{
    public class ExecutiveRepository : IExecutiveRepository
    {
        private NpgsqlConnection conn;
        private readonly IHttpContextAccessor httpContextAccessor;


        public ExecutiveRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            conn = new NpgsqlConnection(configuration.GetConnectionString("DefaultConnection"));
            this.httpContextAccessor = httpContextAccessor;

        }

        public bool ExecutiveLogin(ExecutiveLoginModel executiveLoginModel)
        {
            conn.Open();
            using (var cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = "SELECT * FROM t_executive_login WHERE c_id=@c_id AND c_password=@c_password";
                cmd.Parameters.AddWithValue("c_id", executiveLoginModel.c_id);
                cmd.Parameters.AddWithValue("c_password", executiveLoginModel.c_password);
                // cmd.Parameters.AddWithValue("c_type", executiveLoginModel.c_type);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    httpContextAccessor.HttpContext.Session.SetString("c_id", reader.GetString(0));
                    httpContextAccessor.HttpContext.Session.SetString("c_type", reader.GetString(2));
                }
                else
                {
                    return false;

                }
            }
            conn.Close();
            return true;
        }

        public List<CustomerTokenModel> GetTokens()
        {
            List<CustomerTokenModel> customerTokenModels = new List<CustomerTokenModel>();
            conn.Open();
            using (var cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = "SELECT * FROM t_customer_token where c_token_type = @t_token_type";
                var tokenType = httpContextAccessor.HttpContext.Session.GetString("c_type");
                cmd.Parameters.AddWithValue("t_token_type", tokenType);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    CustomerTokenModel customerTokenModel = new CustomerTokenModel();
                    customerTokenModel.c_id = reader.GetInt32(0);
                    customerTokenModel.c_token_id = reader.GetInt32(1);
                    customerTokenModel.c_token_type = reader.GetString(2);
                    customerTokenModel.c_status = reader.GetString(3);
                    customerTokenModels.Add(customerTokenModel);
                }
            }
            conn.Close();
            return customerTokenModels;
        }
    }

}

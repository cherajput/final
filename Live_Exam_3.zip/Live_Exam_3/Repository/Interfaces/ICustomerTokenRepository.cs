using Microsoft.AspNetCore.Http;
using Npgsql;
using Microsoft.Extensions.Configuration;
using Repository.Models;
namespace Repository.Interfaces;

public interface ICustomerTokenRepository
{
    public int AddToken(CustomerTokenModel customerTokenModel);
    public void UpdateTokenStatus(CustomerTokenModel customerTokenModel);
    public List<CustomerTokenModel> GetTokens();
    public CustomerTokenModel GetToken(int id);

}

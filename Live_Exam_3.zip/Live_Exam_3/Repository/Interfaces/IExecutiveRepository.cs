using Repository.Models;
namespace Repository.Interfaces
{
    public interface IExecutiveRepository
    {
       public bool ExecutiveLogin(ExecutiveLoginModel executiveLoginModel);
       public List<CustomerTokenModel> GetTokens();

    }
}
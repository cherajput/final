namespace Repository.Models
{
    public class CustomerTokenModel
    {
        //c_id,c_token_id,c_token_type,c_status,c_customer_name,c_customer_phone
        public int c_id { get; set; }
        public int c_token_id { get; set; }
        public string c_token_type { get; set; }
        public string c_status { get; set; }
        public string? c_customer_name { get; set; }
        public string? c_customer_phone { get; set; }

    }
}

namespace Repository.Models;
public class ExecutiveLoginModel
{
    public string c_id { get; set; }
    public string c_password { get; set; }
    public string c_type { get; set; }
}
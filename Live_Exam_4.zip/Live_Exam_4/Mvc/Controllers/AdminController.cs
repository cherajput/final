using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;
using Mvc.Models;

namespace Mvc.Controllers;

public class AdminController : Controller
{
    private readonly ILogger<AdminController> _logger;
    private readonly IAdminRepository _adminRepository;

    public AdminController(ILogger<AdminController> logger, IAdminRepository adminRepository)
    {
        _logger = logger;
        _adminRepository = adminRepository;
    }


    public IActionResult Index()
    {
        var trips = _adminRepository.GetTrips();
        return View(trips);
    }

    public IActionResult AddTrip()
    {
        return View();
    }
    [HttpPost]
    public IActionResult AddTrip(TripModel trip)
    {
        _adminRepository.AddTrip(trip);
        return RedirectToAction("Index");
    }

    public IActionResult UpdateTrip(int id)
    {
        var trip = _adminRepository.GetTripById(id);
        return View(trip);
    }
    [HttpPost]
    public IActionResult UpdateTrip(TripModel trip)
    {
        _adminRepository.UpdateTrip(trip);
        return RedirectToAction("Index");
    }

    public IActionResult DeleteTrip(int id)
    {
        _adminRepository.DeleteTrip(id);
        return RedirectToAction("Index");
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

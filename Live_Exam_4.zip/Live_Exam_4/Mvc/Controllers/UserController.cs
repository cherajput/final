using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using mvc.Models;
using mvc.Repositories;

namespace Mvc.Controllers
{

    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;
        private readonly IUserRepository _userRepository;
        private readonly IAdminRepository _adminRepository;
        public UserController(ILogger<UserController> logger, IUserRepository userRepository, IAdminRepository adminRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
            _adminRepository = adminRepository;
        }


        public IActionResult Index()
        {
            var userid = HttpContext.Session.GetString("userid");
            if (userid == null)
            {
                return RedirectToAction("Login");
            }
            var bookings = _userRepository.GetBookings();
            foreach (var booking in bookings)
            {
                var date = booking.c_date;
                var today = DateTime.Today;
                if (booking.c_date < DateTime.Today && booking.c_status == "Scheduled")
                {
                    _userRepository.UpdateTripStatus(booking.c_id.Value);
                }
            }
            TempData["Cancel"] = "no";
            return View(bookings);
        }

        public IActionResult AddBooking()
        {
            var trips = _adminRepository.GetTrips();
            var tripsToAdd = new List<TripModel>();

            foreach (var trip in trips)
            {
                if (trip.c_current_stock != 0)
                {
                    tripsToAdd.Add(trip);
                }
            }



            ViewBag.trips = new SelectList(tripsToAdd, "c_trip", "c_trip");
            TempData["added"] = "no";
            return View();
        }
        [HttpPost]
        public IActionResult AddBooking(BookTrip bookTrip)
        {
            bookTrip.c_available_tickets = _adminRepository.GetTripByName(bookTrip.c_trip).c_current_stock - bookTrip.c_quantity;
            _userRepository.AddBooking(bookTrip);
            TempData["added"] = "yes";
            return View();
        }

        public IActionResult GetBookingById(string id)
        {
            var booking = _adminRepository.GetTripByName(id);
            return Json(booking);
        }

        public IActionResult Cancel(int c_id)
        {
            _userRepository.DeleteBooking(c_id);
            TempData["Cancel"] = "yes";
            return RedirectToAction("Index");
        }

        public IActionResult History()
        {
            var bookings = _userRepository.GetBookingHistory();
            return View(bookings);
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult KendoLogin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserModel user)
        {
            if (_userRepository.Login(user))
            {
                if (HttpContext.Session.GetString("userrole") == "admin")
                {
                    return RedirectToAction("Index", "Admin");
                }
                else if (HttpContext.Session.GetString("userrole") == "user")
                {

                    return RedirectToAction("Index", "user");
                }
            }

            else
            {
                return Ok("wrong");
            }
            return Ok("wrong");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }


        public IActionResult Register()
        {
            ViewBag.msg = null;
            return View();
        }

        public IActionResult KendoRegister()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserModel user)
        {
            if (!_userRepository.IsUser(user.c_email))
            {

                _userRepository.AddUser(user);

            }
            else
            {
                ViewBag.msg = "User already exists";
                return View();

            }
            return RedirectToAction("Login");
        }


    }
}
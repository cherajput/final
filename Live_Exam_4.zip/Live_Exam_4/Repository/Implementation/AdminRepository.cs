using Npgsql;
using mvc.Models;
using mvc.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace mvc.Repositories;

public class AdminRepository : IAdminRepository
{
    private readonly string _conn;
    private readonly NpgsqlConnection conn;
    private NpgsqlConnection connForTask;
    private readonly IHttpContextAccessor access;
    public AdminRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        _conn = config.GetConnectionString("GroupA");
        conn = new NpgsqlConnection(_conn);
        connForTask = new NpgsqlConnection(_conn);
        access = accessor;
    }

    public void AddTrip(TripModel trip)
    {
        try
        {
            conn.Open();
            string query = "insert into public.t_trip(c_trip,c_price,c_ticket_stock,c_current_stock) values(@t,@p,@ts,@cs)";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@t", trip.c_trip);
            command.Parameters.AddWithValue("@p", trip.c_price);
            command.Parameters.AddWithValue("@ts", trip.c_ticket_stock);
            command.Parameters.AddWithValue("@cs", trip.c_current_stock);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public void DeleteTrip(int id)
    {
        try
        {
            conn.Open();
            string query = "delete from public.t_trip where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public TripModel GetTripById(int id)
    {
        TripModel trip = new TripModel();
        try
        {
            conn.Open();
            string query = "select * from public.t_trip where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                trip.c_id = reader.GetInt32(0);
                trip.c_trip = reader.GetString(1);
                trip.c_price = reader.GetString(2);
                trip.c_ticket_stock = reader.GetInt32(3);
                trip.c_current_stock = reader.GetInt32(4);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return trip;
    }

    public TripModel GetTripByName(string name)
    {
        TripModel trip = new TripModel();
        try
        {
            conn.Open();
            string query = "select * from public.t_trip where c_trip=@name";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@name", name);
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                trip.c_id = reader.GetInt32(0);
                trip.c_trip = reader.GetString(1);
                trip.c_price = reader.GetString(2);
                trip.c_ticket_stock = reader.GetInt32(3);
                trip.c_current_stock = reader.GetInt32(4);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return trip;
    }

    public List<TripModel> GetTrips()
    {
        List<TripModel> trips = new List<TripModel>();
        try
        {
            conn.Open();
            string query = "select * from public.t_trip order by c_id asc";
            var command = new NpgsqlCommand(query, conn);
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                TripModel trip = new TripModel();
                trip.c_id = reader.GetInt32(0);
                trip.c_trip = reader.GetString(1);
                trip.c_price = reader.GetString(2);
                trip.c_ticket_stock = reader.GetInt32(3);
                trip.c_current_stock = reader.GetInt32(4);
                trips.Add(trip);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return trips;
    }

    public void UpdateTrip(TripModel trip)
    {
        try
        {
            conn.Open();
            string query = "update public.t_trip set c_trip=@t,c_price=@p,c_ticket_stock=@ts,c_current_stock=@cs where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@t", trip.c_trip);
            command.Parameters.AddWithValue("@p", trip.c_price);
            command.Parameters.AddWithValue("@ts", trip.c_ticket_stock);
            command.Parameters.AddWithValue("@cs", trip.c_current_stock);
            command.Parameters.AddWithValue("@id", trip.c_id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

}
using Npgsql;
using mvc.Models;
using mvc.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;



namespace mvc.Repositories;

public class UserRepository : IUserRepository
{
    private readonly string _conn;
    private readonly NpgsqlConnection conn;
    private NpgsqlConnection connForTask;
    private readonly IHttpContextAccessor access;
    public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        _conn = config.GetConnectionString("GroupA");
        conn = new NpgsqlConnection(_conn);
        connForTask = new NpgsqlConnection(_conn);
        access = accessor;
    }

    public void AddUser(UserModel user)
    {
        try
        {

            var hasher = new PasswordHasher<UserModel>();
            user.c_password = hasher.HashPassword(user, user.c_password);
            conn.Open();

            string query = "insert into public.t_usermaster(c_username,c_email,c_password,c_role) values(@u,@e,@p,'employee')";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@u", user.c_username);
            command.Parameters.AddWithValue("@e", user.c_email);
            command.Parameters.AddWithValue("@p", user.c_password);

            command.ExecuteNonQuery();


        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public bool IsUser(string email)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_usermaster where c_email=@email";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@email", email);
            var reader = command.ExecuteReader();

            // Check if there is at least one row in the result set
            if (reader.Read())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return false;
    }

    public bool Login(UserModel user)
    {
        try
        {
            conn.Open();
            string query = "select c_id, c_username, c_email, c_password, c_role from public.t_usermaster where c_email = @email";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@email", user.c_email);
            // command.Parameters.AddWithValue("@password", user.c_password);

            var rows = command.ExecuteReader();
            if (rows.Read())
            {

                if (VerifyPassword(rows["c_password"].ToString(), user.c_password))
                {

                    string username = rows["c_username"].ToString();
                    string role = rows["c_role"].ToString();
                    access.HttpContext.Session.SetInt32("userid", rows.GetInt32(0));
                    access.HttpContext.Session.SetString("userrole", role);
                    access.HttpContext.Session.SetString("useremail", user.c_email);
                    access.HttpContext.Session.SetString("username", username);

                    return true;
                }
                else
                {
                    return false;
                }



            }
            else
            {
                return false;
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);

        }
        finally
        {
            conn.Close();
        }
        return false;
    }

    public void UpdateUsername(string username)
    {
        try
        {
            conn.Open();
            int userId = access.HttpContext.Session.GetInt32("userid") ?? 0;
            access.HttpContext.Session.SetString("username", username);
            string query = "update public.t_usermaster set c_username = @username where c_id = @userId";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@userId", userId);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public bool VerifyPassword(string storedHash, string providedPassword)
    {
        var passwordHasher = new PasswordHasher<UserModel>();
        var result = passwordHasher.VerifyHashedPassword(null, storedHash, providedPassword);

        return result == PasswordVerificationResult.Success;
    }

    public List<string> GetTasksByUserId()
    {
        List<string> tasks = new List<string>();
        try
        {
            conn.Open();

            // Retrieve user ID from session
            int userId = access.HttpContext.Session.GetInt32("userid") ?? 0;

            // Query to get tasks by user ID
            string query = "SELECT c_task FROM public.t_usertask WHERE c_user = @userId";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@userId", userId);

            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                int taskId = Convert.ToInt32(reader["c_task"]);
                string taskName = GetTaskNameById(taskId); // Use a separate method to get task name
                tasks.Add(taskName);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return tasks;
    }

    public string GetTaskNameById(int id)
    {
        string taskName = "";
        // Create a new connection
        try
        {
            connForTask.Open();

            // Query to get task name by ID
            string query = "SELECT c_task FROM public.t_tasks WHERE c_id = @taskId";
            var command = new NpgsqlCommand(query, connForTask);
            command.Parameters.AddWithValue("@taskId", id);

            var reader = command.ExecuteReader();
            if (reader.Read())
            {
                taskName = reader["c_task"].ToString();
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            connForTask.Close();
        }
        return taskName;
    }

    public void AddBooking(BookTrip bookTrip)
    {
        try
        {
            conn.Open();
            string query = "insert into public.t_book_trip(c_trip,c_date,c_price,c_available_tickets,c_quantity,c_cost,c_status,c_user_id) values(@t,@d,@p,@at,@q,@c,@s,@u)";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@t", bookTrip.c_trip);
            command.Parameters.AddWithValue("@d", bookTrip.c_date);
            command.Parameters.AddWithValue("@p", bookTrip.c_price);
            command.Parameters.AddWithValue("@at", bookTrip.c_available_tickets);
            command.Parameters.AddWithValue("@q", bookTrip.c_quantity);
            command.Parameters.AddWithValue("@c", bookTrip.c_cost);
            command.Parameters.AddWithValue("@s", "Scheduled");
            var userid = access.HttpContext.Session.GetInt32("userid") ?? 0;
            command.Parameters.AddWithValue("@u", userid);
            command.ExecuteNonQuery();

            string query2 = "update public.t_trip set c_current_stock = c_current_stock - @q where c_trip = @t";
            var command2 = new NpgsqlCommand(query2, conn);
            command2.Parameters.AddWithValue("@q", bookTrip.c_quantity);
            command2.Parameters.AddWithValue("@t", bookTrip.c_trip);
            command2.ExecuteNonQuery();

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public List<BookTrip> GetBookings()
    {
        List<BookTrip> bookings = new List<BookTrip>();
        try
        {
            conn.Open();
            string query = "select * from public.t_book_trip where c_status='Scheduled' and c_user_id=@userid";
            var command = new NpgsqlCommand(query, conn);
            var userid = access.HttpContext.Session.GetInt32("userid") ?? 0;
            command.Parameters.AddWithValue("@userid", userid);
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                BookTrip bookTrip = new BookTrip();
                bookTrip.c_id = reader.GetInt32(0);
                bookTrip.c_trip = reader.GetString(1);
                bookTrip.c_date = reader.GetDateTime(2);
                bookTrip.c_price = reader.GetString(3);
                bookTrip.c_available_tickets = reader.GetInt32(4);
                bookTrip.c_quantity = reader.GetInt32(5);
                bookTrip.c_cost = reader.GetInt32(6);
                bookTrip.c_status = reader.GetString(7);
                bookTrip.c_user_id = reader.GetInt32(8);
                bookings.Add(bookTrip);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return bookings;
    }


    public void DeleteBooking(int id)
    {
        try
        {
            conn.Open();
            string query = "update public.t_book_trip set c_status='Cancelled' where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public List<BookTrip> GetBookingHistory()
    {
        List<BookTrip> bookings = new List<BookTrip>();
        try
        {
            conn.Open();
            string query = "select * from public.t_book_trip where c_user_id=@userid";
            var command = new NpgsqlCommand(query, conn);
            var userid = access.HttpContext.Session.GetInt32("userid") ?? 0;
            command.Parameters.AddWithValue("@userid", userid);
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                BookTrip bookTrip = new BookTrip();
                bookTrip.c_id = reader.GetInt32(0);
                bookTrip.c_trip = reader.GetString(1);
                bookTrip.c_date = reader.GetDateTime(2);
                bookTrip.c_price = reader.GetString(3);
                bookTrip.c_available_tickets = reader.GetInt32(4);
                bookTrip.c_quantity = reader.GetInt32(5);
                bookTrip.c_cost = reader.GetInt32(6);
                bookTrip.c_status = reader.GetString(7);
                bookings.Add(bookTrip);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return bookings;
    }

    public void UpdateTripStatus(int id)
    {
        try
        {
            conn.Open();
            string query = "update public.t_book_trip set c_status='Departed' where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }
}
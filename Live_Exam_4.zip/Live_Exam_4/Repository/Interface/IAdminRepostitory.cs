using mvc.Models;
namespace mvc.Repositories;
public interface IAdminRepository{
    
    public List<TripModel> GetTrips();
    public void AddTrip(TripModel trip);
    public void UpdateTrip(TripModel trip);
    public void DeleteTrip(int id);
    public TripModel GetTripById(int id);
    public TripModel GetTripByName(string name);

}
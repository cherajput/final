using Microsoft.AspNetCore.Mvc;
using MasterMvc.Models;
using MasterMvc.Repositories;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.IO;

namespace MasterMvc.Controllers
{
    public class AdminAjaxController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        public AdminAjaxController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            var employees = _employeeRepository.GetEmployees();
            return Json(employees);
        }

        [HttpGet]
        public IActionResult GetEmployee(int id)
        {
            
            var departments = _employeeRepository.GetDepartments();
            ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
            var employee = _employeeRepository.GetEmployee(id);
            return Json(employee);
        }

        [HttpGet]
        public IActionResult GetDepartments()
        {
            var departments = _employeeRepository.GetDepartments();
            return Json(departments);
        }

        [HttpGet]
        public IActionResult Create()
        {
            var departments = _employeeRepository.GetDepartments();
            ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
            return View();
        }
        
        [HttpPost]
        public IActionResult Create(EmployeeModel employee)
        {
            if (employee.Image != null)
            {
                var path = "wwwroot/images/" + employee.Image.FileName;
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    employee.Image.CopyTo(stream);
                }
                employee.c_image = employee.Image.FileName;
            }

            _employeeRepository.AddEmployee(employee);
            return Json(employee);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var employee = _employeeRepository.GetEmployee(id);
            var departments = _employeeRepository.GetDepartments();
            ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
            return View();
        }

        [HttpPost]
        public IActionResult Edit(EmployeeModel employee)
        {
            if (employee.Image != null)
            {
                var path = "wwwroot/images/" + employee.Image.FileName;
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    employee.Image.CopyTo(stream);
                }
                employee.c_image = employee.Image.FileName;
            }
            else
            {
                var oldEmployee = _employeeRepository.GetEmployee(employee.c_id.Value);
                employee.c_image = oldEmployee.c_image;
            }

            _employeeRepository.UpdateEmployee(employee);
            return RedirectToAction("Index", "Admin");
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            _employeeRepository.DeleteEmployee(id);
            return Json(new { success = true });
        }
    }
}

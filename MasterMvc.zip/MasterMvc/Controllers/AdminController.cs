using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MasterMvc.Models;
using MasterMvc.Repositories;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MasterMvc.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;
        private readonly IEmployeeRepository _employeeRepository;

        public AdminController(ILogger<AdminController> logger, IEmployeeRepository employeeRepository)
        {
            _logger = logger;
            _employeeRepository = employeeRepository;
        }

        public IActionResult Index()
        {
            var employees = _employeeRepository.GetEmployees();
            return View(employees);
        }

        public IActionResult Create()
        {
            var departments = _employeeRepository.GetDepartments();
            ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(EmployeeModel employee)
        {
            if (employee.Image != null)
            {
                var path = "wwwroot/images/" + employee.Image.FileName;
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    employee.Image.CopyTo(stream);
                }
                employee.c_image = employee.Image.FileName;
            }

            _employeeRepository.AddEmployee(employee);
            return RedirectToAction("Index","Admin");
        }


        public IActionResult Edit(int id)
        {
            var employee = _employeeRepository.GetEmployee(id);
            var departments = _employeeRepository.GetDepartments();
            ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
            return View(employee);
        }

        [HttpPost]
        public IActionResult Edit(EmployeeModel employee)
        {
            if (employee.Image != null)
            {
                var path = "wwwroot/images/" + employee.Image.FileName;
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    employee.Image.CopyTo(stream);
                }
                employee.c_image = employee.Image.FileName;
            }
            else
            {
                var oldEmployee = _employeeRepository.GetEmployee(employee.c_id.Value);
                employee.c_image = oldEmployee.c_image;
            }

            _employeeRepository.UpdateEmployee(employee);
            return RedirectToAction("Index","Admin");
        }

        public IActionResult Delete(int id)
        {
            _employeeRepository.DeleteEmployee(id);
            return RedirectToAction("Index");
        }
    }
}

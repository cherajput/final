using System.Diagnostics;
using MasterMvc.Models;
using MasterMvc.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MasterMvc.Controllers;

public class AdminKendoCompController : Controller
{
    private readonly ILogger<AdminKendoCompController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IEmployeeRepository _employeeRepository;

    public AdminKendoCompController(ILogger<AdminKendoCompController> logger, IUserRepository userRepository, IEmployeeRepository employeeRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _employeeRepository = employeeRepository;
    }


    public IActionResult Index()
    {
        return View();
    }

    public IActionResult GetDepartments()
    {
        var departments = _employeeRepository.GetDepartments();
        return Json(departments);
    }

    public IActionResult GetData()
    {
        var employees = _employeeRepository.GetEmployees();
        return Json(employees);
    }
    public static string file = "";
    [HttpPost]
    public IActionResult UploadPhoto(EmployeeModel city)
    {
        if (city.Image != null)
        {
            string filename = city.Image.FileName;
            //convert filename to unique using guid
            filename = Guid.NewGuid() + filename;
            string filepath = "wwwroot/images/" + filename;

            using (var stream = new FileStream(filepath, FileMode.Create))
            {

                city.Image.CopyTo(stream);
            }

            file = filename;

        }

        return Json("a");
    }

    public IActionResult Create()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }

    [HttpPost]
    public IActionResult Create(EmployeeModel employee)
    {

        employee.c_image = file;
        _employeeRepository.AddEmployee(employee);
        return Json("index");
    }

    [HttpGet]
    public IActionResult Edit()
    {

        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }

    public IActionResult GetEmployee(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        return Json(employee);
    }

    [HttpPost]
    public IActionResult Edit(EmployeeModel employee)
    {
        employee.c_image = file;
        _employeeRepository.UpdateEmployee(employee);
        return Json("index");
    }

    public IActionResult Delete(int id)
    {
        _employeeRepository.DeleteEmployee(id);
        return Ok("index");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

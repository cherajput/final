using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MasterMvc.Models;
using MasterMvc.Repositories;

namespace mvc.Controllers;

public class EmployeeController : Controller
{
    private readonly ILogger<EmployeeController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IEmployeeRepository _employeeRepository;

    public EmployeeController(ILogger<EmployeeController> logger, IUserRepository userRepository, IEmployeeRepository employeeRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _employeeRepository = employeeRepository;
    }

    public IActionResult Index()
    {
        var username = HttpContext.Session.GetString("username");
        var employees = _employeeRepository.GetEmployeeFromUsername(username);
        return View(employees);
    }

    public IActionResult KendoIndex()
    {
        var username = HttpContext.Session.GetString("username");
        var employees = _employeeRepository.GetEmployeeFromUsername(username);
        return View(employees);
    }

    public IActionResult Create()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }

    public IActionResult KendoCreate()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }

    [HttpPost]
    public IActionResult Create(EmployeeModel employee)
    {
        //select last index of employee.shift




        if (employee.Image != null)
        {
            var path = "wwwroot/images/" + employee.Image.FileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                employee.Image.CopyTo(stream);
            }
            employee.c_image = employee.Image.FileName;
        }

        _employeeRepository.AddEmployee(employee);
        return RedirectToAction("index");
    }

    public IActionResult Edit(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View(employee);
    }

    public IActionResult KendoEdit(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View(employee);
    }

    [HttpPost]
    public IActionResult Edit(EmployeeModel employee)
    {
        var oldEmployee = _employeeRepository.GetEmployee(employee.c_id.Value);
        if (employee.Image != null)
        {
            var path = "wwwroot/images/" + employee.Image.FileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                employee.Image.CopyTo(stream);
            }
            employee.c_image = employee.Image.FileName;
        }
        else
        {
            employee.c_image = oldEmployee.c_image;
        }
        employee.c_shift = oldEmployee.c_shift;
        employee.c_department = oldEmployee.c_department;
        _userRepository.UpdateUsername(employee.c_name);
        _employeeRepository.UpdateEmployee(employee);
        return RedirectToAction("index");
    }

    public IActionResult Delete(int id)
    {
        _employeeRepository.DeleteEmployee(id);
        return RedirectToAction("index");
    }


    public IActionResult GetDepartment()
    {
        var departments = _employeeRepository.GetDepartments();
        return Json(departments);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MasterMvc.Models;
using MasterMvc.Repositories;

namespace MasterMvc.Controllers
{
    public class UserKendoController : Controller
    {
        private readonly ILogger<UserKendoController> _logger;
        private readonly IUserRepository _userRepository;

        public UserKendoController(ILogger<UserKendoController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserModel user)
        {
            if (_userRepository.Login(user))
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["loginfailed"] = "Wrong credentials";
                return View();
            }
        }

        public IActionResult Register()
        {
            ViewBag.msg = null;
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserModel user)
        {
            if (!_userRepository.IsEmailExist(user.c_email))
            {
                _userRepository.AddUser(user);
            }
            else
            {
                ViewBag.emailexist = "User already exists";
                return View();
            }
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}

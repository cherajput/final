using MasterMvc.Models;
using Npgsql;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace MasterMvc.Repositories
{   
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly NpgsqlConnection conn;
        private readonly IConfiguration _config;

        public EmployeeRepository(IConfiguration config)
        {
            _config = config;
            conn = new NpgsqlConnection(_config.GetConnectionString("DefaultConnection"));
        }

        public List<EmployeeModel> GetEmployees()
        {

            List<EmployeeModel> employees = new List<EmployeeModel>();
            try
            {
                conn.Open();
                string sql = "SELECT * FROM t_employeemaster";
                var cmd = new NpgsqlCommand(sql, conn);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    employees.Add(new EmployeeModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_gender = reader.GetString(2),
                        c_dob = reader.GetDateTime(3),
                        c_shift = reader[4] as string[],
                        c_department = reader.GetInt32(5),
                        c_image = reader.GetString(6)
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return employees;
        }

        public List<DepartmentModel> GetDepartments()
        {
            List<DepartmentModel> departments = new List<DepartmentModel>();

            try
            {
                conn.Open();

                string sql = "SELECT * FROM t_departments";
                var cmd = new NpgsqlCommand(sql, conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    departments.Add(new DepartmentModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1)
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while retrieving departments: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }

            return departments;
        }


        public void AddEmployee(EmployeeModel employee)
        {
            try
            {
                conn.Open();
                string sql = "INSERT INTO t_employeemaster (c_name, c_gender, c_dob, c_shift, c_department, c_image) VALUES (@Name, @Gender, @Dob, @Shift, @Department, @Image)";
                var cmd = new NpgsqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("Name", employee.c_name);
                cmd.Parameters.AddWithValue("Gender", employee.c_gender);
                cmd.Parameters.AddWithValue("Dob", employee.c_dob);
                cmd.Parameters.AddWithValue("Shift", employee.c_shift);
                cmd.Parameters.AddWithValue("Department", employee.c_department);
                cmd.Parameters.AddWithValue("Image", employee.c_image);

                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding employee: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        public EmployeeModel GetEmployee(int id)
        {
            EmployeeModel employee = null;
            try
            {
                conn.Open();
                string sql = "SELECT * FROM t_employeemaster WHERE c_id = @Id";
                var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("Id", id);

                var reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    employee = new EmployeeModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_gender = reader.GetString(2),
                        c_dob = reader.GetDateTime(3),
                        c_shift = reader[4] as string[],
                        c_department = reader.GetInt32(5),
                        c_image = reader.GetString(6)
                    };
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while retrieving employee: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
            return employee;
        }

        public void UpdateEmployee(EmployeeModel employee)
        {
            try
            {
                conn.Open();
                string sql = "UPDATE t_employeemaster SET c_name = @Name, c_gender = @Gender, c_dob = @Dob, c_shift = @Shift, c_department = @Department, c_image = @Image WHERE c_id = @Id";
                var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("Id", employee.c_id);
                cmd.Parameters.AddWithValue("Name", employee.c_name);
                cmd.Parameters.AddWithValue("Gender", employee.c_gender);
                cmd.Parameters.AddWithValue("Dob", employee.c_dob);
                cmd.Parameters.AddWithValue("Shift", employee.c_shift);
                cmd.Parameters.AddWithValue("Department", employee.c_department);
                cmd.Parameters.AddWithValue("Image", employee.c_image);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while updating employee: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteEmployee(int id)
        {
            try
            {
                conn.Open();
                string sql = "DELETE FROM t_employeemaster WHERE c_id = @Id";
                var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("Id", id);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while deleting employee: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }



        public EmployeeModel GetEmployeeFromUsername(string username)
    {
        try
        {
            conn.Open();
            var query = "select * from t_employeemaster where c_name=@username";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@username", username);
            var reader = command.ExecuteReader();
            if (reader.Read())
            {
                var employee = new EmployeeModel();
                employee.c_id = reader.GetInt32(0);
                employee.c_name = reader.GetString(1);
                employee.c_gender = reader.GetString(2);
                employee.c_dob = reader.GetDateTime(3);
                employee.c_shift = (string[])reader["c_shift"];
                employee.c_department = reader.GetInt32(5);
                employee.c_image = reader.GetString(6);
                return employee;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return null;
    }
    }
}

using MasterMvc.Models;

namespace MasterMvc.Repositories
{
    public interface IEmployeeRepository
    {

        public List<EmployeeModel> GetEmployees();
        public List<DepartmentModel> GetDepartments();
        public void AddEmployee(EmployeeModel employee);
        public EmployeeModel GetEmployee(int id);
        public void UpdateEmployee(EmployeeModel employee);
        public void DeleteEmployee(int id);
        public EmployeeModel GetEmployeeFromUsername(string username);
    }

}
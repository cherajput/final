using MasterMvc.Models;

namespace MasterMvc.Repositories
{
    public interface IUserRepository
    {
        public void AddUser(UserModel user);
        public bool IsEmailExist(string email);
        public bool Login(UserModel user);
        public bool VerifyPassword(string storedHash, string providedPassword);
        public void UpdateUsername(string username);
    }
}

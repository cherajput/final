using Npgsql;
using Microsoft.AspNetCore.Identity;
using MasterMvc.Models;
using MasterMvc.Repositories;



namespace MasterMvc.Repositories
{

    public class UserRepository : IUserRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        // private readonly NpgsqlConnection conn2;
        private readonly IHttpContextAccessor access;
        public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            _conn = config.GetConnectionString("DefaultConnection");
            conn = new NpgsqlConnection(_conn);
            // conn2 = new NpgsqlConnection(_conn);
            access = accessor;
        }

        public void AddUser(UserModel user)
        {
            try
            {

                var hasher = new PasswordHasher<UserModel>();
                user.c_password = hasher.HashPassword(user, user.c_password);
                conn.Open();

                string query = "insert into public.t_usermaster(c_username,c_email,c_password,c_role) values(@u,@e,@p,'user')";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@u", user.c_username);
                command.Parameters.AddWithValue("@e", user.c_email);
                command.Parameters.AddWithValue("@p", user.c_password);

                command.ExecuteNonQuery();


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public bool IsEmailExist(string email)
        {
            try
            {
                conn.Open();
                string query = "select * from public.t_usermaster where c_email=@email";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@email", email);
                var reader = command.ExecuteReader();

                // Check if there is at least one row in the result set
                if (reader.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        public bool Login(UserModel user)
        {
            try
            {
                conn.Open();
                string query = "select c_id, c_username, c_email, c_password, c_role from public.t_usermaster where c_email = @email";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@email", user.c_email);
                // command.Parameters.AddWithValue("@password", user.c_password);

                var rows = command.ExecuteReader();
                if (rows.Read())
                {

                    if (VerifyPassword(rows["c_password"].ToString(), user.c_password))
                    {

                        string username = rows["c_username"].ToString();
                        string role = rows["c_role"].ToString();
                        access.HttpContext.Session.SetInt32("userid", rows.GetInt32(0));
                        access.HttpContext.Session.SetString("userrole", role);
                        access.HttpContext.Session.SetString("useremail", user.c_email);
                        access.HttpContext.Session.SetString("username", username);

                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        public void UpdateUsername(string username)
    {
        try
        {
            conn.Open();
            int userId = access.HttpContext.Session.GetInt32("userid") ?? 0;
            access.HttpContext.Session.SetString("username", username);
            string query = "update public.t_usermaster set c_username = @username where c_id = @userId";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@userId", userId);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }



        public bool VerifyPassword(string storedHash, string providedPassword)
        {
            var passwordHasher = new PasswordHasher<UserModel>();
            var result = passwordHasher.VerifyHashedPassword(null, storedHash, providedPassword);

            return result == PasswordVerificationResult.Success;
        }
    }
}
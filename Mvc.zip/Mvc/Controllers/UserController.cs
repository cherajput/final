using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mvc.Models;
using Microsoft.Extensions.Logging;
using Mvc.Repositories;

namespace Mvc.Controllers;

public class UserController : Controller
{
    private readonly ILogger<UserController> _logger;
    private readonly IUserRepository _userRepository;
    

    public UserController(ILogger<UserController> logger, IUserRepository userRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        
    }
   


    
   
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Login(UserMaster login)
    {
        if(_userRepository.Login(login))
        {
            if(HttpContext.Session.GetString("c_role") == "admin")
            {
                return RedirectToAction("Index", "User");
            }
            else if(HttpContext.Session.GetString("c_role") == "user")
            {
                return RedirectToAction("Index", "Item");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        else
        {
            return RedirectToAction("Index", "Home");
        }
    }
  

}

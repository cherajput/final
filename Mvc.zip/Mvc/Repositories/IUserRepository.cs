using Mvc.Repositories;
using Mvc.Models;

namespace Mvc.Repositories
{
    public interface IUserRepository
    {
      public bool Login (UserMaster login);
    }
}

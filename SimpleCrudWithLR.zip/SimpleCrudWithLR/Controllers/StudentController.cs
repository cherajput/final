using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Models;
using Repository;

namespace SimpleCrudWithLR.Controllers
{

    public class StudentController : Controller
    {
        private readonly ILogger<StudentController> _logger;
        private readonly IStudentRepository _studentRepository;

        public StudentController(ILogger<StudentController> logger, IStudentRepository studentRepository)
        {
            _logger = logger;
            _studentRepository = studentRepository;
        }

        [HttpGet]
        public IActionResult Index()
        {
        var role = HttpContext.Session.GetString("role");
            if(role == "Admin")
            {
            var student = _studentRepository.GetAllStudents();
            return View(student);
            }
            else
            {
                return RedirectToAction("Login", "User");
            }
        }

        [HttpGet]
        public IActionResult Insert()
        {
            ViewBag.Courses = _studentRepository.GetAllCourses();
            return View();
        }

        [HttpPost]
        public IActionResult Insert(StudentModel studentModel)
        {
            
            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(studentModel.Photo.FileName);
            var path = Path.Combine("wwwroot/images", fileName);
            using (var stream = new FileStream(path, FileMode.Create))
            {
                studentModel.Photo.CopyTo(stream);
            }
            studentModel.c_profile = fileName;
             var userid = HttpContext.Session.GetInt32("userid");
            studentModel.c_userid = userid.Value;
            _studentRepository.AddStudent(studentModel);
            return View();
        }
        [HttpGet]
        public IActionResult Edit()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Edit(StudentModel studentModel)
        {
            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(studentModel.Photo.FileName);
            var path = Path.Combine("wwwroot/images", fileName);
            using (var stream = new FileStream(path, FileMode.Create))
            {
                studentModel.Photo.CopyTo(stream);
            }
            studentModel.c_profile = fileName;
            _studentRepository.UpdateStudent(studentModel);
            return View();
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            _studentRepository.DeleteStudent(id);
            return View();
        }

       



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}
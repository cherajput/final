using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Models;
using OfficeOpenXml;
using Repository;

namespace SimpleCrudWithLR.Controllers
{

    public class StudentKendoController : Controller
    {
        private readonly ILogger<StudentKendoController> _logger;
        private readonly IStudentRepository _studentRepository;

        public StudentKendoController(ILogger<StudentKendoController> logger, IStudentRepository studentRepository)
        {
            _logger = logger;
            _studentRepository = studentRepository;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAllStudents()
        {
            var student = _studentRepository.GetAllStudents();
            return Json(student);
        }

        [HttpPost]
        public IActionResult UploadPhoto(IFormFile Photo)
        {
            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(Photo.FileName);
            var path = Path.Combine("wwwroot/images", fileName);
            using (var stream = new FileStream(path, FileMode.Create))
            {
                Photo.CopyTo(stream);
            }

            return Ok(new { fileName = fileName });
        }
        [HttpPost]
        public IActionResult AddStudent(StudentModel studentModel)
        {
            var userid = HttpContext.Session.GetInt32("userid");
            studentModel.c_userid = userid.Value;
            _studentRepository.AddStudent(studentModel);
            return Ok();

        }


        [HttpPost]
        public IActionResult EditStudent(StudentModel studentModel)
        {
            _studentRepository.UpdateStudent(studentModel);
            return Ok();
        }

        [HttpDelete]
        public IActionResult DeleteStudent(int id)
        {
            _studentRepository.DeleteStudent(id);
            return Ok();
        }

        [HttpDelete]
        public IActionResult DeleteStudents([FromBody] List<int> ids)
        {
            _studentRepository.DeleteStudents(ids);
            return Ok();
        }

        [HttpGet]
        public IActionResult GetAllCourses()
        {
            var course = _studentRepository.GetAllCourses();
            return Json(course);
        }

        [HttpGet]
        public IActionResult GetCourse(int id)
        {
            var course = _studentRepository.GetCourse(id);
            return Json(course);
        }

        public IActionResult DownloadExcel()
        {
            byte[] fileContents;

            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Students");

                // Assuming your model has properties c_id, c_name, c_dob, c_gender, c_address, c_language, c_course, c_phone, c_profile
                worksheet.Cells[1, 1].Value = "Id";
                worksheet.Cells[1, 2].Value = "Name";
                worksheet.Cells[1, 3].Value = "Date of Birth";
                worksheet.Cells[1, 4].Value = "Gender";
                worksheet.Cells[1, 5].Value = "Address";
                worksheet.Cells[1, 6].Value = "Language";
                worksheet.Cells[1, 7].Value = "Course";
                worksheet.Cells[1, 8].Value = "Phone";
                worksheet.Cells[1, 9].Value = "Profile";

                var students = _studentRepository.GetAllStudents(); // Replace _context with _studentRepository

                for (int i = 0; i < students.Count; i++)
                {
                    var student = students[i];

                    worksheet.Cells[i + 2, 1].Value = student.c_id;
                    worksheet.Cells[i + 2, 2].Value = student.c_name;
                    worksheet.Cells[i + 2, 3].Value = student.c_dob;
                    worksheet.Cells[i + 2, 4].Value = student.c_gender;
                    worksheet.Cells[i + 2, 5].Value = student.c_address;
                    worksheet.Cells[i + 2, 6].Value = student.c_language;
                    worksheet.Cells[i + 2, 7].Value = student.c_course;
                    worksheet.Cells[i + 2, 8].Value = student.c_phone;
                    worksheet.Cells[i + 2, 9].Value = student.c_profile;
                }

                fileContents = package.GetAsByteArray();
            }

            if (fileContents == null || fileContents.Length == 0)
            {
                return NotFound();
            }

            return File(
                fileContents: fileContents,
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileDownloadName: "Students.xlsx"
            );
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}
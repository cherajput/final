namespace Models
{
    public class CourseModel
    {
        public int? c_id { get; set; }
        public string c_name { get; set; }
    }
}
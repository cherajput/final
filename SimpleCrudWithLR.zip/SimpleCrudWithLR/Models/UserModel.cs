namespace Models
{
    public class Usermodel
    {
        public int? id { get; set; }
        public string c_username { get; set; }
        public string c_email { get; set; }
        public string c_password { get; set; }
        public string c_role { get; set; }
        public string ConfirmPassword { get; set; }
    }

}
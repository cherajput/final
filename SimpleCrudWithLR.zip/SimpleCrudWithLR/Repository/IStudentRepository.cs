using Models;

namespace Repository
{
    public interface IStudentRepository
    {
        public List<StudentModel> GetAllStudents();
        public void AddStudent(StudentModel studentModel);
        public void UpdateStudent(StudentModel studentModel);
        public void DeleteStudent(int id);
        public List<CourseModel> GetAllCourses();
        public CourseModel GetCourse(int id);
        public void DeleteStudents(List<int> ids);

    }
}
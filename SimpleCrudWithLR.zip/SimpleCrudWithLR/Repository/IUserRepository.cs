using Models;

namespace Repository
{
    public interface IUserRepository
    {
        public void AddUser(Usermodel usermodel);
        public bool IsUser(string c_email);
        public bool Login(Usermodel usermodel);
    }
}
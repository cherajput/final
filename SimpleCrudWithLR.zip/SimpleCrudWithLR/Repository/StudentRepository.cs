using System.Data;
using Models;
using Npgsql;

namespace Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor _accessor;
        public StudentRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            conn = new NpgsqlConnection(config.GetConnectionString("DefaultConnection"));
            _accessor = accessor;
        }

        public List<StudentModel> GetAllStudents()
        {
            try
            {
                List<StudentModel> students = new List<StudentModel>();
                conn.Open();
                var query = "Select * from t_student";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        StudentModel student = new StudentModel();
                        student.c_id = reader.GetInt32(0);
                        student.c_name = reader.GetString(1);
                        student.c_dob = reader.GetDateTime(2);
                        student.c_gender = reader.GetString(3);
                        student.c_address = reader.GetString(4);
                        student.c_language = reader[5] as string[];
                        student.c_course = reader.GetInt32(6);
                        student.c_phone = reader.GetString(7);
                        student.c_profile = reader.GetString(8);
                        students.Add(student);
                    }
                    return students;
                }

            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }
        public void AddStudent(StudentModel studentModel)
        {
            try
            {
                conn.Open();
                var query = "Insert into t_student(c_name, c_dob, c_gender,c_address,c_language,c_course,c_phone,c_profile,c_userid) values (@name,@dob,@gender,@address,@lang,@course,@phone,@profile,@userid)";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", studentModel.c_name);
                cmd.Parameters.AddWithValue("@dob", studentModel.c_dob);
                cmd.Parameters.AddWithValue("@gender", studentModel.c_gender);
                cmd.Parameters.AddWithValue("@address", studentModel.c_address);
                cmd.Parameters.AddWithValue("@lang", studentModel.c_language);
                cmd.Parameters.AddWithValue("@course", studentModel.c_course);
                cmd.Parameters.AddWithValue("@phone", studentModel.c_phone);
                cmd.Parameters.AddWithValue("@profile", studentModel.c_profile);
                cmd.Parameters.AddWithValue("@userid", studentModel.c_userid);
                cmd.ExecuteNonQuery();

            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteStudent(int id)
        {
            try
            {
                conn.Open();
                var query = "delete from t_student where c_id = @id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();

            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteStudents(List<int> ids)
        {
            try
            {
                conn.Open();


                var query = @"DELETE FROM t_student WHERE c_id = ANY(@ids)";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ids", ids);
                cmd.ExecuteNonQuery();

            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        // public void DeleteStudents(List<int> ids)
        // {
        //     try
        //     {
        //         conn.Open();

        //         foreach (var id in ids)
        //         {
        //             var query = @"DELETE FROM t_student WHERE c_id = @id;";
        //             var cmd = new NpgsqlCommand(query, conn);
        //             cmd.Parameters.AddWithValue("@id", id);
        //             cmd.ExecuteNonQuery();
        //         }
        //     }
        //     catch (System.Exception ex)
        //     {
        //         System.Console.WriteLine(ex.Message);
        //     }
        //     finally
        //     {
        //         conn.Close();
        //     }
        // }



        public void UpdateStudent(StudentModel studentModel)
        {
            try
            {
                conn.Open();
                var query = "Update t_student set c_name=@name, c_dob=@dob, c_gender=@gender, c_language=@lang, c_course=@course, c_phone=@phone, c_profile=@profile where c_id=@id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", studentModel.c_name);
                cmd.Parameters.AddWithValue("@dob", studentModel.c_dob);
                cmd.Parameters.AddWithValue("@gender", studentModel.c_gender);
                cmd.Parameters.AddWithValue("@lang", studentModel.c_language);
                cmd.Parameters.AddWithValue("@course", studentModel.c_course);
                cmd.Parameters.AddWithValue("@phone", studentModel.c_phone);
                cmd.Parameters.AddWithValue("@profile", studentModel.c_profile);
                cmd.Parameters.AddWithValue("@id", studentModel.c_id);

                cmd.ExecuteNonQuery();
            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {

                conn.Close();

            }
        }

        public List<CourseModel> GetAllCourses()
        {

            try
            {
                List<CourseModel> courseModels = new List<CourseModel>();
                conn.Open();
                var query = "Select * from t_course";
                var cmd = new NpgsqlCommand(query, conn);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    CourseModel courseModel = new CourseModel();

                    courseModel.c_id = reader.GetInt32(0);
                    courseModel.c_name = reader.GetString(1);
                    courseModels.Add(courseModel);

                }
                return courseModels;
            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public CourseModel GetCourse(int id)
        {
            CourseModel course = null;
            try
            {
                conn.Open();
                var query = "select * from t_course where c_id = @id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    course = new CourseModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1)

                    };
                }
            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return course;
        }
    }
}
using Models;
using Npgsql;

namespace Repository
{
    public class UserRepository : IUserRepository
    {

        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor _accessor;
        public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
        {
            conn = new NpgsqlConnection(config.GetConnectionString("DefaultConnection"));
            _accessor = accessor;
        }
        public void AddUser(Usermodel usermodel)
        {
            try
            {
                conn.Open();
                var query = "INSERT INTO t_users(c_username,c_email,c_password,c_role) Values (@u,@e,@p,'User')";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@u", usermodel.c_username);
                    cmd.Parameters.AddWithValue("@e", usermodel.c_email);
                    cmd.Parameters.AddWithValue("@p", usermodel.c_password);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public bool IsUser(string c_email)
        {
            try
            {
                conn.Open();
                var query = "select * from t_users where c_email = @e Limit 1";
                using (var cmd = new NpgsqlCommand(query,conn))
                {
                    cmd.Parameters.AddWithValue("@e", c_email);
                    var reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        public bool Login(Usermodel usermodel)
        {
            try
            {
                conn.Open();
                var query = "Select c_username,c_id,c_role from t_users where c_email = @e and c_password = @p";
                using (var cmd = new NpgsqlCommand(query,conn))
                {
                    cmd.Parameters.AddWithValue("@e", usermodel.c_email);
                    cmd.Parameters.AddWithValue("@p", usermodel.c_password);
                    var reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        _accessor.HttpContext.Session.SetString("username", reader.GetString(0));
                        _accessor.HttpContext.Session.SetInt32("userid", reader.GetInt32(1));
                        _accessor.HttpContext.Session.SetString("role", reader.GetString(2));
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return false;
        }
    }
}